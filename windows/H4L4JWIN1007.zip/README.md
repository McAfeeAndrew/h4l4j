# h4l4j
EEDK packages for ePO to help locate vulnerable log4j in your environment

## Process

WORK IN PROGRESS